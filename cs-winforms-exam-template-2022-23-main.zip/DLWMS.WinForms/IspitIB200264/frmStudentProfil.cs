﻿using DLWMS.Data;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DLWMS.WinForms.IspitIB200264
{
    public partial class frmStudentProfil : Form
    {
        private Student odabraniStudent;

        public frmStudentProfil()
        {
        }

        public frmStudentProfil(Student odabraniStudent)
        {
            InitializeComponent();
            this.odabraniStudent = odabraniStudent;
            lblStudent.Text = odabraniStudent.Ime;
        }
    }
}
